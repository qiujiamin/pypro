#coding=utf-8

#--------system model(1~9999)--------
#common code
SYSTEM_OK = 1           #�ɹ�
SYSTEM_FAIL = -1        #ʧ��

#--------user model(10000~19999)--------
NOT_ALLOWED_COUTRIES                = -10001    #your country is not allow to visit 
INTERFACE_NEED_PARAMS               = -11100    #need necessary params

#signup
USER_SIGNUP_CODEWITHNOTEL           = -11002    #use affiliate code that need verify tel, but no tel
USER_SIGNUP_JURISDICTION_NOTMATCH   = -11003    #jurisdiction not match
USER_SIGNUP_SITEID_NOTMATCH         = -11004    #stieid not match
USER_SIGNUP_GB_ADDRESS_INVALID      = -11005    #gb check: address invalid
USER_SIGNUP_GB_NAME_INVALID         = -11006    #gb check: firstname or lastname invalid
USE_SIGNUP_GB_MOBILE_PRIFIX_INVALID = -11007    #gb check: mobile prifix invalid
USE_SIGNUP_IE_MOBILE_PRIFIX_INVALID = -11008    #ie cehck: mobile prifix invalid
USE_SIGNUP_CURRENCY_INVALID         = -11009    #currency invalid
USER_SIGNUP_EMAIL_EXIST             = -11010    #email exist
USER_SIGNUP_USER_EXIST              = -11011    #user hash exist
USER_SIGNUP_EMAIL_DISPOSALBE        = -11012    #email domain disposalbe
USER_SIGNUP_PHONENUMBER_EXIST       = -11013    #mobile number exist
USER_SIGNUP_AFFILIATECODE_INVALID   = -11014    #affiliatecode invalid
USER_NEED_TEL_VERIFY                = -11015    #need to verify by user's tel
USER_VERIFICATIONCODE_NOT_MATCH     = -11016    #verificationcode not match
USER_NEED_EMAIL_VERIFY              = -11017    #need to verify by user's email
USER_EMAIL_ALREADY_VERIFIED         = -11018    #user's email already verified
USER_RESEND_VERIFICATIONCODE_ERROR  = -11019    #verificationcode resend error
USER_BIRTHDAY_IS_NOT_ILLEGAL        = -11020    #You must be %s or older to register!
USER_ID3GLOBAL_CHECK_NOT_PASS       = -11021    #id3global check not pass 
NO_LOGIN_SUPPORTED_IN_THIS_VERSION  = -11022    #In this version, no login is supported
PERSONAL_NUMBER_IS_INVALIDATE       = -11023    # personal number is invalidate
PERSONAL_NUMBER_NOT_MATCH_BIRTHDATE = -11024    # personal number and birthdate is different
BIRTHDAY_IS_ILLEGAL                 = -11025    # birthday is illegal



#login
USER_LOGIN_INVALID_EMAIL                = -11101    #invalid email
USER_LOGIN_PASSWORD_INCORRECT           = -11102    #invalid password
USER_LOGIN_ACCOUNT_IS_LOCKED            = -11103    #user locked
USER_LOGIN_ACCOUNT_PERMANENTLY_LOCKED   = -11104    #user permanently locked
USER_LOGIN_AFFILIATES_ACCOUNT           = -11105    #affiliates account can't login
USER_NOT_LOGIN                          = -11106    # user not login no usercheck param
USERID_NOT_ALLOW_EMPTY                  = -11107    # userid is not allow empty
USERID_USERCHECK_NOT_MATCH              = -11108    # userid and usercheck not match
ALREADY_SEND_EMAIL_IN_TEN_MINS          = -11109    # user already send email to reset the password in ten minutes
LOGIN_RECORD_MISSING                    = -11110    # user's last login record is missing
LOGIN_SESSION_EXPIRED                   = -11111    # user's login session expired sso
USER_QUICK_LOGIN_ERROR                  = -11112    # quick login includes fingerprint-login, faceid-login and guesture-login
NOT_NEWEST_DEV                          = -11113
GENERATE_SALT_ERROR                     = -11114
EXTERNAL_LOGIN_ERROR                    = -11115    # The external login status is invalid.
USER_ACCOUNT_NOT_BIND                   = -11116    # Need to bind
USER_ACCOUNT_BIND_ERROR                 = -11117    # Bind occur error
ACCOUNT_ALREADY_BINDING                 = -11118    # 3th party account is already bind with other multilotto account.
LOGIN_FAILED_TEN_TIMES                  = -11119    # login failed 10 times
PERSONAL_NUMBER_IS_EMPTY                = -11120    # personal number is empty,need to enter
PERSONAL_NUMBER_IS_EXIST                = -11121    # personal number is exist



#����
USER_INVALID                            = -11200    #user not exist
EMAIL_INVALID                           = -11201    #email not exist
DUP_LIMIT_CTRL_ERROR                    = -11202    # dup limit ctrl return 
ERROR_WITHDRAWAL_NOT_CANCELLED          = -11203    #error withdrawal not cancelled
USER_OLD_PASSWORD_NOT_MATCH             = -11204    #user's old password not match
USER_REPEATNEWPASSWORD_NOT_MATCH        = -11205    #Repeatnewpassword not match newpassword
USER_ACCOUNT_TIMEOUT                    = -11206    #user's account status is timeout
USER_ACCOUNT_SELF_EXCLUSION             = -11207    #user's account status is self exclusion
JURISDICTION_CANT_REVOKE                = -11208    #Only MGA and Ireland and CURACAO users can revoke
NOT_YET_REOPEN                          = -11209    #It's not yet reopen
TIMEOUT_COOLDOWN_OFF                    = -11210    #cooldown off for account timeout
USER_ACCOUNT_ID3GLOBAL_ONHOLD           = -11211    # account status onhold because id3global check failed 
USER_ACCOUNT_ONHOLD                     = -11212    # account status onhold
USER_VERIFICATION_TEL_NOT_THE_SAME      = -11213    # verification tel is not the same
COMM_CHANNEL_NOT_FOUND                  = -11214    # communication_channel_id not found
COMM_CATEGORY_NOT_FOUND                 = -11215    # communication_category_id not found

LOGIN_MODE_NOT_FOUND                    = -11216
PUSH_ALREADY_CANCELLED                  = -11217    # push already cancelled
UPDATE_USER_INFO_FAILED                 = -11218    # update user info failed
SYSTEM_MIGRATION                        = -11219    # system migration
SE_OFFICIAL_CERT_FAILED                 = -11220    # sweden official certification
SE_OFFICIAL_CERT_ERROR                  = -11221    # sweden official certification error (eg:timeout)

#վ�������
#�������
#--------������ط�����(20000~29999)--------
DB_PARAMS_ERROR                         =   -20000      # need necessary db
USER_NOT_ENOUGH_CASH                    =   -20001      # user do not have enough cash
CREATE_TRANSACTION_ERROR                =   -20002      # could not create the transaction
CREATE_TICKET_TRANSACTION_ERROR         =   -20003      # could not create the ticket transaction


#--------֧����ط�����(30000~39999)--------
ERROR_WITHDRAWAL_NOT_CANCALLED          =   -30000
PAY_PARAMS_ERROR                        =   -30001      # Payment's params is invaild.
PAY_CARD_NUMBER_ERROR                   =   -30002      # Payment's card number is invaild.
PAY_CC_DISABLED                         =   -30003      # User is not allow to use the cc.
CREATE_PENDING_DEPOSIT_ERROR            =   -30004      # Create pending deposit error.
TICKET_CREDIT_LIMIT_ERROR               =   -30005      # User's credit card limit reached.
PAY_COMPLETE_ERROR                      =   -30006      # Could not complete the payment.
PAID_ALREADY                            =   -30007


#--------������ط�����(40000~49999)--------
# order
ORDER_LINES_NOT_ALLOW_EMPTY         = -40000    # You must play at least 1 line
ORDER_DRAWINGS_INVAILD              = -40001    # total drawings is invaild
ORDER_GAMETYPE_INVAILD              = -40002    # gametypeid is invaild
GAME_RESULTS_PENDING                = -40003    # gametype nextdraw is less than now
MULTIPLE_LINES_WITH_SAME_NUMBERS    = -40004    # multiple lines with the same numbers
SUBSCRIPTIONPLAN_INVAILD            = -40005    # subscriptionplanid is invaild
LINES_WITH_WRONG_NUMBERS            = -40006    # verified lines with error
REQUIRES_PLAY_EVEN_NUMBER           = -40007    # This lottery requires you to play an even number of rows
PLAY_ONLY_ONE_LINE_WITH_TRIAL       = -40008    # using trial only can choose one line
NEED_EMAIL_VERIFIED                 = -40009    # need to verified email
NEED_ACCEPTED_DEPOSIT_TERMS         = -40010    # need deposit terms
NOT_ENOUGH_FREEDRAWINGS             = -40011    # not enough freedrawings
ORDER_NOT_PENDING                   = -40012    # order is not pending
ERROR_GROUP_MIN_SHARES              = -40013    # error group min shares
ERROR_GROUP_MISSING_NAME            = -40014    # error group missing name
ERROR_GROUP_LONG_NAME               = -40015    # error group long name
ERROR_GROUP_BUY_PRICE               = -40016    # error group buy price
WRONG_MONEY                         = -40017    # wrong money
WRONG_TYPE                          = -40018    # wrong ticket_type or plan_type
NOT_ENOUGH_MONEY                    = -40019    # account not enough money
ERROR_INVALID_GROUP_PLAY            = -40020    # error invalid group play
ERROR_INVALID_ORDER                 = -40021    # error invalid order
ERROR_GENERIC_ERROR                 = -40022    # error generic error
GROUP_NAME_IS_EXITED                = -40023    # group name is exited
FAVORITE_NUMBERS_HAS_SAVED          = -40024    # favorite numbers has saved
ERROR_INVALID_REDEEM_CODE           = -40025    # error invalid redeem code
ERROR_INVALID_CVC                   = -40026    # error invalid cvc
NEED_DEPOSIT_TERMS                  = -40027    # need deposit terms
WRONG_AMOUNT                        = -40028    # the order money is wrong
ORDER_LINES_ISNOT_ENOUGHT           = -40029    # You need to buy at least miniticket tickets
GAME_ISNOT_ALLOW_BUY          = -40030    # The game is not allow buy in the current jurisdictions
ORDER_SYSTEM_LINES_NOT_ALLOW_ONE    = -40031    # You need to select at least %s numbers to play this system
WAGERLIMIT                          = -40032    # You have reached your wagering limit of %s'%wagerlimit+str(user_info['accountcurrency'])+' for this period.
LOSSLIMIT                           = -40033    # You have reached your loss limit of %s'%wagerlimit+str(user_info['accountcurrency'])+' for this period.
#--------��Ѷ��ط�����(50000~59999)-------- 

#--------������ط�����(60000~69999)--------

#--------���ﳵ��ط�����(70000~79999)--------
EMPTY_CART                          = -70000    # cart is empty while addcart
UPDATE_PARAMLIST_ERROR              = -70001    # failed to update paramlist
CANOT_FIND_CARDORDER                = -70002    # can not find cardorder by cardorderid

#--------new freetickets(80000~89999)------------------
NOT_ENOUGH_NEW_FREETICKETS          = -80000
HAVE_NO_NEW_FREETICKETS             = -80001
